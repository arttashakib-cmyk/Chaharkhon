# چهارچین (Chaharchin)
Native Android (Kotlin + Jetpack Compose), Persian RTL, 300 levels.

## Build (GitHub Actions)
Push the repo → Actions → "Build APK" → download artifact `Chaharchin-APK`.
(No gradle wrapper needed; the workflow installs Gradle 8.7.)

## Add more word groups
Edit `app/src/main/assets/categories.txt` — one line per group:
`tier|title|word،word،word،...`  (tier 1 easy … 4 very hard; ≥4 words, 8–10 is ideal)
Shortcuts: `P:سر` → "سر + … یک کلمه معنادار است", `S:خانه` → "… + خانه یک کلمه معنادار است".
Levels are generated deterministically from this file at startup.

## Rename the app
`app/src/main/res/values/strings.xml` and the texts in `Ui.kt` (TopBars).
