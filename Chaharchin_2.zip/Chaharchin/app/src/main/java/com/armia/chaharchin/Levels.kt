package com.armia.chaharchin

import android.content.Context
import kotlin.random.Random

private val LIMITED = setOf("اجزای", "فیلم‌های", "آثار", "یک", "نام", "اصطلاحات", "با", "مترادف", "وام‌واژه‌های", "پادشاهان")

class Cat(val tier: Int, val title: String, val words: List<String>, val assoc: Boolean = false) {
    val set: Set<String> = words.toHashSet()

    /** categories of the same "kind" never appear together in one level (keeps levels varied) */
    val kind: String = when {
        assoc -> "assoc"
        title.contains(" + …") || title.startsWith("… +") || title.endsWith("…") || title.startsWith("بعد از") -> "phrase"
        title.substringBefore(' ') in LIMITED -> title.substringBefore(' ')
        else -> title
    }
}

class Group(val title: String, val words: List<String>, val rank: Int)

class Level(
    val number: Int,
    val groups: List<Group>,
    val start: List<String>,
    val catIdx: List<Int>
) {
    val groupOf: Map<String, Int> = buildMap {
        groups.forEachIndexed { i, g -> g.words.forEach { put(it, i) } }
    }
}

/**
 * Levels are generated deterministically from assets/categories.txt.
 * Line format:  tier|title|word،word،word،...
 *   tier 1 = easy ... tier 4 = very hard
 *   title shortcuts:  P:xxx  ->  "xxx + … یک کلمه معنادار است"
 *                     S:xxx  ->  "… + xxx یک کلمه معنادار است"
 * Add lines to the file and levels will use them automatically.
 */
object Levels {
    const val COUNT = 300

    private var cats: List<Cat> = emptyList()
    private var seed: Long = 1L
    val categoryCount: Int get() = cats.size

    fun init(ctx: Context, userSeed: Long) {
        seed = userSeed
        if (cats.isNotEmpty()) return
        val out = ArrayList<Cat>()
        ctx.assets.open("categories.txt").bufferedReader(Charsets.UTF_8).useLines { lines ->
            lines.forEach { raw ->
                val line = raw.trim()
                if (line.isEmpty() || line.startsWith("#")) return@forEach
                val p = line.split("|")
                if (p.size < 3) return@forEach
                val tier = p[0].trim().toIntOrNull() ?: return@forEach
                val t = p[1].trim()
                val assoc = t.startsWith("@")
                val title = when {
                    assoc -> t.drop(1)
                    t.startsWith("P:") -> t.drop(2) + " + … یک کلمه معنادار است"
                    t.startsWith("S:") -> "… + " + t.drop(2) + " یک کلمه معنادار است"
                    else -> t
                }
                val words = p[2].split("،").map { it.trim() }.filter { it.isNotEmpty() }.distinct()
                if (words.size >= 4) out.add(Cat(tier, title, words, assoc))
            }
        }
        cats = out
    }

    private fun plan(n: Int): List<Int> = when {
        n <= 10 -> listOf(1, 2, 2, 3)
        n <= 30 -> listOf(2, 2, 3, 3)
        n <= 60 -> if (n % 2 == 0) listOf(2, 3, 3, 4) else listOf(2, 3, 3, 3)
        n <= 150 -> if (n % 2 == 0) listOf(3, 3, 3, 4) else listOf(2, 3, 3, 3)
        else -> when {
            n % 3 == 0 -> listOf(3, 3, 4, 4)
            n % 2 == 0 -> listOf(3, 3, 3, 4)
            else -> listOf(3, 3, 3, 3)
        }
    }

    /** how many different partitions of these 16 words into the 4 categories exist (capped at 2) */
    private fun solutions(ws: List<String>, cs: List<Cat>): Int {
        val allowed = ws.map { w -> cs.indices.filter { w in cs[it].set } }
        if (allowed.any { it.isEmpty() }) return 0
        val order = ws.indices.sortedBy { allowed[it].size }
        val cnt = IntArray(cs.size)
        var found = 0
        fun go(k: Int) {
            if (found >= 2) return
            if (k == order.size) { found++; return }
            for (c in allowed[order[k]]) {
                if (cnt[c] < 4) { cnt[c]++; go(k + 1); cnt[c]-- }
            }
        }
        go(0)
        return found
    }

    /**
     * Builds one level.  Harder levels (higher n) deliberately pick categories that share words
     * and pick the words that fit several categories (decoys), while still guaranteeing
     * that exactly ONE valid solution exists.
     */
    private fun build(n: Int, attempt: Int, usage: IntArray?, strict: Boolean): Level? {
        val rng = Random(seed * 31L + n * 7919L + attempt * 104729L + 17L)
        val baseBias = when { n <= 4 -> 0; n <= 40 -> 1; else -> 2 }
        // if a combination keeps failing the uniqueness check, relax the decoy pressure
        val bias = (baseBias - attempt / 25).coerceAtLeast(0)
        val chosen = ArrayList<Int>()
        for (tier in plan(n)) {
            val union = HashSet<String>()
            chosen.forEach { union.addAll(cats[it].words) }
            val cand = cats.indices
                .filter { i ->
                    cats[i].tier == tier && i !in chosen &&
                        chosen.count { cats[it].kind == cats[i].kind } < (if (cats[i].kind == "assoc" && n > 120) 2 else 1)
                }
                .map { i ->
                    val ov = minOf(cats[i].words.count { it in union }, 3)
                    i to (rng.nextInt(1000) + (usage?.get(i) ?: 0) * 1000 - bias * ov * 800)
                }
                .sortedBy { it.second }
            if (cand.isEmpty()) return null
            // widen the pool of candidates as attempts fail, so one stubborn category can't block a level
            val k = minOf(cand.size, 1 + attempt / 4)
            chosen.add(cand[rng.nextInt(k)].first)
        }
        val cs = chosen.map { cats[it] }

        var best: List<List<String>>? = null
        var bestScore = -1
        repeat(if (bias == 0) 6 else 30) {
            val used = HashSet<String>()
            val ws = ArrayList<List<String>>()
            var ok = true
            var decoys = 0
            for (i in cs.indices) {
                val pool = cs[i].words.filter { it !in used }
                if (pool.size < 4) { ok = false; break }
                val others = cs.filterIndexed { j, _ -> j != i }
                val pick = pool
                    .map { w -> w to (others.count { w in it.set } * bias * 600 + rng.nextInt(1000)) }
                    .sortedByDescending { it.second }
                    .take(4).map { it.first }
                decoys += pick.sumOf { w -> others.count { w in it.set } }
                used.addAll(pick)
                ws.add(pick)
            }
            if (ok && (!strict || solutions(ws.flatten(), cs) == 1) && decoys > bestScore) {
                best = ws; bestScore = decoys
            }
        }
        val picked = best ?: return null
        val groups = picked.mapIndexed { i, w -> Group(cs[i].title, w, i) }
        val start = picked.flatten().shuffled(rng)
        return Level(n, groups, start, chosen)
    }

    val all: List<Level> by lazy {
        val usage = IntArray(cats.size)
        (1..COUNT).map { n ->
            var lv: Level? = null
            var a = 0
            while (lv == null && a < 300) { lv = build(n, a, usage, true); a++ }
            a = 0
            while (lv == null && a < 300) { lv = build(n, a, usage, false); a++ }
            val r = lv!!
            r.catIdx.forEach { usage[it]++ }
            r
        }
    }

    fun practice(): Level =
        (0..200).firstNotNullOf { build(0, it, null, true) }
}
