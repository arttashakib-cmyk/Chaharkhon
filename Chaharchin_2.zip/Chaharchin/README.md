# چهارچین (Chaharchin)
Native Android (Kotlin + Jetpack Compose), Persian RTL, 300 levels.

## Build (GitHub Actions)
Push the repo → Actions → "Build APK" → download artifact `Chaharchin-APK`.
(No gradle wrapper needed; the workflow installs Gradle 8.7.)

## Add more word groups
Edit `app/src/main/assets/categories.txt` — one line per group:
`tier|title|word،word،word،...`  (tier 1 easy … 4 very hard; ≥4 words, 8–10 is ideal)
Shortcuts: `P:سر` → "سر + … یک کلمه معنادار است", `S:خانه` → "… + خانه یک کلمه معنادار است".
Levels are generated deterministically from this file at startup.

## Rename the app
`app/src/main/res/values/strings.xml` and the texts in `Ui.kt` (TopBars).

## v2
- Home screen; levels are generated per install from a random seed (kept in app data).
- Harder levels: decoy words that fit more than one group, with an automatic check that every level has exactly one solution.
- App is signed with `app/chaharchin.jks` (always the same key) and versionCode = GitHub run number, so each new build installs as an update.
  Keep this keystore — never regenerate it, or updates will refuse to install.

## v3
- ~415 hand-written groups: trivia (history, cinema, science, geography), phrase-completion ("هفت…", "بعد از «خط»"), hidden-word and reversal tricks.
- Level plan is harder from level 1; each level uses at most one group of the same "kind"; every level still has exactly one solution.

## v3.1
- Score breakdown like the reference app: +25 per group you find, −5 per wrong guess, up to +60 time bonus (shown on the result card with elapsed time).
- ~50 "association" groups (@ lines in categories.txt): everything about one person/city/film/brand, e.g. Apple, Newton, Isfahan, Interstellar.
