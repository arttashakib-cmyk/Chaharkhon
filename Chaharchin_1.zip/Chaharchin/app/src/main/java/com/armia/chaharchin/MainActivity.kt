package com.armia.chaharchin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // every install gets its own random level set (seed is created once and kept)
        val sp = getSharedPreferences("chaharchin2", MODE_PRIVATE)
        var seed = sp.getLong("seed", 0L)
        if (seed == 0L) {
            seed = java.util.Random().nextLong() or 1L
            sp.edit().putLong("seed", seed).apply()
        }
        Levels.init(applicationContext, seed)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(
                    colorScheme = lightColorScheme(
                        primary = C.ink, onPrimary = C.bg, background = C.bg, surface = C.bg, onSurface = C.ink
                    )
                ) {
                    val model = remember { AppModel(applicationContext) }
                    App(model)
                }
            }
        }
    }
}
