package com.armia.chaharchin

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay

enum class Phase { Playing, Won, Lost }

class Toast(val text: String)

class GameState(val level: Level) {
    var tiles by mutableStateOf(level.start)
    var selected by mutableStateOf(setOf<String>())
    var solved by mutableStateOf(listOf<Int>())
    var mistakes by mutableStateOf(0)
    var phase by mutableStateOf(Phase.Playing)
    var shakeTick by mutableStateOf(0)
    var busy by mutableStateOf(false)
    var toast by mutableStateOf<Toast?>(null)
    var found by mutableStateOf(0)          // groups the player found himself
    val startMs = System.currentTimeMillis()
    var endMs by mutableStateOf(0L)
    private val tried = HashSet<Set<String>>()

    val elapsedSec: Int
        get() = (((if (endMs > 0L) endMs else System.currentTimeMillis()) - startMs) / 1000).toInt()
    val groupsPoints: Int get() = found * 25
    val mistakePenalty: Int get() = mistakes * 5
    val timeBonus: Int get() = if (phase == Phase.Won) (60 - elapsedSec / 5).coerceIn(0, 60) else 0
    val score: Int get() = (groupsPoints - mistakePenalty + timeBonus).coerceAtLeast(0)

    fun toggle(w: String) {
        if (phase != Phase.Playing || busy) return
        selected = when {
            w in selected -> selected - w
            selected.size < 4 -> selected + w
            else -> selected
        }
    }

    fun clear() {
        if (!busy) selected = emptySet()
    }

    fun shuffle() {
        if (phase == Phase.Playing && !busy) tiles = tiles.shuffled()
    }

    suspend fun submit(onFinish: (Boolean) -> Unit) {
        if (selected.size != 4 || busy || phase != Phase.Playing) return
        val sel = selected
        if (!tried.add(sel)) {
            toast = Toast("این ترکیب رو قبلاً امتحان کردی")
            return
        }
        busy = true
        val gi = level.groupOf[sel.first()]!!
        val correct = sel.all { level.groupOf[it] == gi }
        if (correct) {
            tiles = sel.toList() + tiles.filter { it !in sel }
            delay(420)
            solved = solved + gi
            found++
            tiles = tiles.filter { it !in sel }
            selected = emptySet()
            if (solved.size == 4) {
                endMs = System.currentTimeMillis()
                phase = Phase.Won
                onFinish(true)
            }
        } else {
            mistakes++
            shakeTick++
            val best = level.groups.indices.filter { it !in solved }
                .maxOf { g -> sel.count { level.groupOf[it] == g } }
            if (best == 3 && mistakes < 4) toast = Toast("یکی مونده!")
            if (mistakes >= 4) {
                delay(700)
                selected = emptySet()
                for (g in level.groups.indices.filter { it !in solved }) {
                    val ws = level.groups[g].words
                    tiles = ws + tiles.filter { it !in ws }
                    delay(450)
                    solved = solved + g
                    tiles = tiles.filter { it !in ws }
                    delay(150)
                }
                endMs = System.currentTimeMillis()
                phase = Phase.Lost
                onFinish(false)
            }
        }
        busy = false
    }
}
