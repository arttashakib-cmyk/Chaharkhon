package com.armia.chaharchin

import androidx.compose.ui.graphics.Color

object C {
    val bg = Color(0xFFFFFEFC)
    val ink = Color(0xFF2D3130)
    val tile = Color(0xFFEEE7DE)
    val muted = Color(0xFF6B6F6D)
    val line = Color(0xFFE6E3DE)
    val dim = Color(0xFFBDBAB5)
    val accent = Color(0xFFA85F45)
    val score = Color(0xFF1F6B52)
    val green = Color(0xFF4FD1A5)
    val blue = Color(0xFF6EA8FE)
    val yellow = Color(0xFFFFC84A)
    val pink = Color(0xFFF07EB0)
    val rank = listOf(green, blue, yellow, pink)
}

fun Int.fa(): String =
    toString().map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")
