package com.armia.chaharchin

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class AppModel(ctx: Context) {
    private val sp = ctx.getSharedPreferences("chaharchin2", Context.MODE_PRIVATE)

    /** index 1..COUNT : -1 = not played, 0 = lost, >0 = best score */
    val results = mutableStateListOf<Int>().apply {
        val saved = sp.getString("res", null)?.split(",")?.map { it.toIntOrNull() ?: -1 }
        for (i in 0..Levels.COUNT) add(saved?.getOrNull(i) ?: -1)
    }
    var played by mutableStateOf(sp.getInt("played", 0))
    var wins by mutableStateOf(sp.getInt("wins", 0))
    var streak by mutableStateOf(sp.getInt("streak", 0))
    var bestStreak by mutableStateOf(sp.getInt("bestStreak", 0))
    var perfect by mutableStateOf(sp.getInt("perfect", 0))
    var current by mutableStateOf(sp.getInt("cur", 1))
    var seenHelp by mutableStateOf(sp.getBoolean("help", false))

    fun best(n: Int): Int = results[n].coerceAtLeast(0)
    fun unlocked(n: Int): Boolean = n == 1 || results[n - 1] >= 0 || results[n] >= 0
    fun completed(): Int = (1..Levels.COUNT).count { results[it] >= 0 }
    fun firstOpen(): Int = (1..Levels.COUNT).firstOrNull { results[it] < 0 } ?: Levels.COUNT

    fun markHelp() { seenHelp = true; save() }
    fun setCurrent(n: Int) { current = n; save() }

    fun record(n: Int, won: Boolean, score: Int) {
        val old = results[n]
        results[n] = if (won) maxOf(old, score) else maxOf(old, 0)
        played++
        if (won) {
            wins++
            streak++
            if (streak > bestStreak) bestStreak = streak
            if (score == 100) perfect++
        } else streak = 0
        if (won && n < Levels.COUNT) current = n + 1
        save()
    }

    fun reset() {
        for (i in 0..Levels.COUNT) results[i] = -1
        played = 0; wins = 0; streak = 0; bestStreak = 0; perfect = 0; current = 1
        save()
    }

    private fun save() {
        sp.edit()
            .putString("res", results.joinToString(","))
            .putInt("played", played).putInt("wins", wins).putInt("streak", streak)
            .putInt("bestStreak", bestStreak).putInt("perfect", perfect)
            .putInt("cur", current).putBoolean("help", seenHelp)
            .apply()
    }
}
