package com.armia.chaharchin

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/* ───────────────────────── App shell ───────────────────────── */

@Composable
fun App(model: AppModel) {
    var screen by remember { mutableStateOf(0) }            // 0 = game, 1 = levels
    var practice by remember { mutableStateOf(false) }
    var levelNo by remember { mutableStateOf(model.current.coerceIn(1, Levels.COUNT)) }
    var replay by remember { mutableStateOf(0) }
    var dialog by remember { mutableStateOf("") }
    val game = remember(levelNo, practice, replay) {
        GameState(if (practice) Levels.practice() else Levels.all[levelNo - 1])
    }

    fun open(n: Int) {
        practice = false
        levelNo = n
        model.setCurrent(n)
        screen = 0
        replay++
    }

    LaunchedEffect(Unit) {
        if (!model.seenHelp) { dialog = "help"; model.markHelp() }
    }
    BackHandler(enabled = screen == 1 || practice) {
        if (screen == 1) screen = 0 else { practice = false; replay++ }
    }

    Surface(Modifier.fillMaxSize(), color = C.bg, contentColor = C.ink) {
        Column(Modifier.fillMaxSize()) {
            TopBars(
                subtitle = when {
                    screen == 1 -> "انتخاب مرحله"
                    practice -> "بازی تمرینی"
                    else -> "مرحله ${levelNo.fa()}"
                },
                onLevels = { screen = 1 },
                onMenu = { dialog = "menu" },
                onStats = { dialog = "stats" },
                onHelp = { dialog = "help" }
            )
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (screen == 1) {
                    LevelsScreen(model) { open(it) }
                } else {
                    GameScreen(
                        g = game, model = model, levelNo = levelNo, practice = practice,
                        onOpen = { open(it) },
                        onLevels = { screen = 1 },
                        onReplay = { replay++ },
                        onExitPractice = { practice = false; replay++ }
                    )
                }
            }
        }
    }

    when (dialog) {
        "menu" -> MenuDialog(
            onClose = { dialog = "" },
            onPick = { id ->
                dialog = ""
                when (id) {
                    "levels" -> screen = 1
                    "stats" -> dialog = "stats"
                    "help" -> dialog = "help"
                    "practice" -> { practice = true; screen = 0; replay++ }
                    "reset" -> dialog = "reset"
                }
            }
        )
        "help" -> HelpDialog(
            onClose = { dialog = "" },
            onPractice = { dialog = ""; practice = true; screen = 0; replay++ }
        )
        "stats" -> StatsDialog(model) { dialog = "" }
        "reset" -> AlertDialog(
            onDismissRequest = { dialog = "" },
            confirmButton = {
                TextButton(onClick = { model.reset(); dialog = ""; open(1) }) { Text("آره، پاک کن", color = C.accent) }
            },
            dismissButton = { TextButton(onClick = { dialog = "" }) { Text("نه، ولش کن") } },
            title = { Text("پاک کردن پیشرفت؟", fontWeight = FontWeight.Bold) },
            text = { Text("همه‌ی مرحله‌ها و آمارت صفر می‌شه و برمی‌گردی به مرحله‌ی اول.") },
            containerColor = C.bg
        )
    }
}

@Composable
fun TopBars(
    subtitle: String,
    onLevels: () -> Unit, onMenu: () -> Unit, onStats: () -> Unit, onHelp: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().height(64.dp).padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("پیوند", fontSize = 32.sp, fontWeight = FontWeight.Black)
        Box(Modifier.padding(horizontal = 14.dp).width(1.dp).height(30.dp).background(C.line))
        Text("بازی‌ها", fontSize = 19.sp, color = C.muted, modifier = Modifier.clickable { onLevels() })
        Spacer(Modifier.weight(1f))
        Box(Modifier.clickable { onMenu() }.padding(6.dp)) { MenuIcon() }
    }
    Box(Modifier.fillMaxWidth().height(1.dp).background(C.line))
    Row(
        Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("چهارچین", fontSize = 28.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.width(14.dp))
        Text(subtitle, fontSize = 18.sp, color = C.muted)
        Spacer(Modifier.weight(1f))
        Box(Modifier.clickable { onStats() }.padding(6.dp)) { StatsIcon() }
        Spacer(Modifier.width(14.dp))
        Box(Modifier.clickable { onHelp() }.padding(6.dp)) { HelpIcon() }
    }
    Box(Modifier.fillMaxWidth().height(1.dp).background(C.line))
}

@Composable
fun MenuIcon() {
    Canvas(Modifier.size(28.dp)) {
        for (i in 0..2) {
            val y = size.height * (0.22f + 0.28f * i)
            drawLine(C.ink, Offset(0f, y), Offset(size.width, y), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
        }
    }
}

@Composable
fun StatsIcon() {
    Canvas(Modifier.size(28.dp)) {
        val w = size.width
        val h = size.height
        drawRect(C.ink, Offset(w * 0.04f, h * 0.38f), androidx.compose.ui.geometry.Size(w * 0.24f, h * 0.58f))
        drawRect(C.ink, Offset(w * 0.38f, h * 0.04f), androidx.compose.ui.geometry.Size(w * 0.24f, h * 0.92f))
        drawRect(C.ink, Offset(w * 0.72f, h * 0.52f), androidx.compose.ui.geometry.Size(w * 0.24f, h * 0.44f))
    }
}

@Composable
fun HelpIcon() {
    Box(Modifier.size(30.dp).border(2.5.dp, C.ink, CircleShape), contentAlignment = Alignment.Center) {
        Text("؟", fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

/* ───────────────────────── Game screen ───────────────────────── */

@Composable
fun GameScreen(
    g: GameState, model: AppModel, levelNo: Int, practice: Boolean,
    onOpen: (Int) -> Unit, onLevels: () -> Unit, onReplay: () -> Unit, onExitPractice: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            if (!practice) {
                NavRow(
                    levelNo = levelNo,
                    canPrev = levelNo > 1,
                    canNext = levelNo < Levels.COUNT && model.unlocked(levelNo + 1),
                    onPrev = { onOpen(levelNo - 1) },
                    onNext = { onOpen(levelNo + 1) }
                )
            }
            if (g.phase == Phase.Playing) {
                Text(
                    "چهار گروه چهارتایی بساز!", fontSize = 18.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp)
                )
            } else Spacer(Modifier.height(16.dp))

            Board(g) { w ->
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                g.toggle(w)
            }

            if (g.phase == Phase.Playing) {
                Spacer(Modifier.height(24.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("اشتباه‌های باقی‌مونده:", fontSize = 18.sp)
                    Spacer(Modifier.width(12.dp))
                    Row(Modifier.width(132.dp)) {
                        repeat(4 - g.mistakes) {
                            Box(Modifier.padding(end = 12.dp).size(20.dp).clip(CircleShape).background(C.ink))
                        }
                    }
                }
                Spacer(Modifier.height(24.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally)
                ) {
                    Pill("ثبت", enabled = g.selected.size == 4 && !g.busy, filled = true) {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        scope.launch {
                            g.submit { won -> if (!practice) model.record(levelNo, won, g.score) }
                        }
                    }
                    Pill("لغو انتخاب", enabled = g.selected.isNotEmpty() && !g.busy) { g.clear() }
                    Pill("بُر زدن", enabled = !g.busy) { g.shuffle() }
                }
                Spacer(Modifier.height(32.dp))
            } else {
                ResultSection(g, model, levelNo, practice, onOpen, onLevels, onReplay, onExitPractice)
            }
        }

        g.toast?.let { t ->
            LaunchedEffect(t) {
                delay(1500)
                if (g.toast === t) g.toast = null
            }
            Box(
                Modifier.align(Alignment.TopCenter).padding(top = 8.dp)
                    .clip(RoundedCornerShape(12.dp)).background(C.ink)
                    .padding(horizontal = 18.dp, vertical = 10.dp)
            ) { Text(t.text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun NavRow(levelNo: Int, canPrev: Boolean, canNext: Boolean, onPrev: () -> Unit, onNext: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        NavBtn("مرحله بعدی", canNext, Modifier.weight(1f), onNext)
        Column(Modifier.weight(0.7f), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("مرحله", fontSize = 14.sp, color = C.muted)
            Text(levelNo.fa(), fontSize = 34.sp, fontWeight = FontWeight.Black)
        }
        NavBtn("مرحله قبلی", canPrev, Modifier.weight(1f), onPrev)
    }
}

@Composable
fun NavBtn(text: String, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier.height(54.dp).clip(shape)
            .border(1.5.dp, if (enabled) C.ink else C.line, shape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = if (enabled) C.ink else C.dim)
    }
}

/* ───────────────────────── Board ───────────────────────── */

@Composable
fun Board(g: GameState, onTap: (String) -> Unit) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val gap = 8.dp
        val tileW = (maxWidth - gap * 3) / 4
        val tileH = 84.dp
        val step = tileH + gap
        Box(Modifier.fillMaxWidth().height(tileH * 4 + gap * 3)) {
            g.solved.forEachIndexed { k, gi ->
                key(gi) {
                    Banner(g.level.groups[gi], Modifier.offset(y = step * k).fillMaxWidth().height(tileH))
                }
            }
            val origin = g.solved.size
            g.tiles.forEachIndexed { i, w ->
                key(w) {
                    Tile(
                        w = w, sel = w in g.selected,
                        x = (tileW + gap) * (i % 4), y = step * (origin + i / 4),
                        wd = tileW, ht = tileH, shakeTick = g.shakeTick
                    ) { onTap(w) }
                }
            }
        }
    }
}

fun tileFont(w: String): Int {
    val longest = w.split(" ").maxOf { it.length }
    return when {
        longest <= 5 -> 19
        longest <= 7 -> 17
        longest <= 9 -> 15
        longest <= 11 -> 13
        else -> 11
    }
}

@Composable
fun Tile(w: String, sel: Boolean, x: Dp, y: Dp, wd: Dp, ht: Dp, shakeTick: Int, onClick: () -> Unit) {
    val ax by animateDpAsState(x, spring(stiffness = Spring.StiffnessMediumLow), label = "x")
    val ay by animateDpAsState(y, spring(stiffness = Spring.StiffnessMediumLow), label = "y")
    val bg by animateColorAsState(if (sel) C.ink else C.tile, tween(150), label = "bg")
    val sc by animateFloatAsState(if (sel) 0.95f else 1f, tween(120), label = "sc")
    val shake = remember { Animatable(0f) }
    LaunchedEffect(shakeTick) {
        if (shakeTick > 0 && sel) {
            for (d in listOf(10f, -10f, 8f, -8f, 4f, 0f)) shake.animateTo(d, tween(45))
        }
    }
    Box(
        Modifier.offset(ax + shake.value.dp, ay).size(wd, ht)
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .clip(RoundedCornerShape(12.dp)).background(bg).clickable(onClick = onClick)
            .padding(horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            w, fontSize = tileFont(w).sp, fontWeight = FontWeight.Bold, maxLines = 2,
            textAlign = TextAlign.Center, color = if (sel) Color.White else C.ink, lineHeight = 22.sp
        )
    }
}

@Composable
fun Banner(gr: Group, modifier: Modifier) {
    val vis = remember { MutableTransitionState(false).apply { targetState = true } }
    AnimatedVisibility(
        visibleState = vis, modifier = modifier,
        enter = fadeIn(tween(250)) + scaleIn(tween(250), initialScale = 0.92f)
    ) {
        Column(
            Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp)).background(C.rank[gr.rank]).padding(horizontal = 8.dp),
            verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(gr.title, fontSize = 17.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = C.ink)
            Text(gr.words.joinToString("، "), fontSize = 15.sp, textAlign = TextAlign.Center, color = C.ink)
        }
    }
}

@Composable
fun Pill(text: String, enabled: Boolean, filled: Boolean = false, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    val bg by animateColorAsState(if (enabled && filled) C.ink else Color.Transparent, label = "pill")
    Box(
        Modifier.height(54.dp).clip(shape).background(bg)
            .border(2.dp, if (enabled) C.ink else C.line, shape)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text, fontSize = 17.sp, fontWeight = FontWeight.Bold,
            color = if (!enabled) C.dim else if (filled) Color.White else C.ink
        )
    }
}

@Composable
fun AccentButton(text: String, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(C.accent).clickable(onClick = onClick)
            .padding(horizontal = 38.dp, vertical = 18.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Color.White) }
}

/* ───────────────────────── Result ───────────────────────── */

@Composable
fun RopeIcon(broken: Boolean) {
    Canvas(Modifier.size(76.dp)) {
        val w = size.width
        val h = size.height
        val col = if (broken) Color(0xFFBDB3A3) else Color(0xFFE9B872)
        val sw = Stroke(width = 15.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        val hi = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        val p = Path().apply {
            moveTo(w * 0.82f, h * 0.92f); lineTo(w * 0.14f, h * 0.92f); lineTo(w * 0.14f, h * 0.42f)
            lineTo(w * 0.5f, h * 0.1f)
            if (!broken) {
                lineTo(w * 0.86f, h * 0.42f); lineTo(w * 0.86f, h * 0.78f)
            } else {
                lineTo(w * 0.66f, h * 0.28f)
            }
        }
        drawPath(p, col, style = sw)
        drawPath(p, Color(0x44FFFFFF), style = hi)
        if (broken) {
            val q = Path().apply { moveTo(w * 0.8f, h * 0.36f); lineTo(w * 0.86f, h * 0.42f); lineTo(w * 0.86f, h * 0.78f) }
            drawPath(q, col, style = sw)
            drawPath(q, Color(0x44FFFFFF), style = hi)
        }
    }
}

fun shareText(g: GameState, levelNo: Int): String {
    val sq = listOf("🟩", "🟦", "🟨", "🟪")
    val sb = StringBuilder("چهارچین – مرحله ${levelNo.fa()}\n")
    g.solved.forEach { gi -> sb.append(sq[g.level.groups[gi].rank].repeat(4)).append('\n') }
    sb.append(if (g.phase == Phase.Won) "امتیاز: ${g.score.fa()}" else "این بار نشد!")
    return sb.toString()
}

@Composable
fun ResultSection(
    g: GameState, model: AppModel, levelNo: Int, practice: Boolean,
    onOpen: (Int) -> Unit, onLevels: () -> Unit, onReplay: () -> Unit, onExitPractice: () -> Unit
) {
    val won = g.phase == Phase.Won
    val ctx = LocalContext.current
    var info by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(30.dp))
        RopeIcon(broken = !won)
        Spacer(Modifier.height(10.dp))
        Text(
            if (won) "پیداشون کردی!" else "رشته پاره شد!",
            fontSize = 42.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(6.dp))
        Text(
            when {
                won && g.mistakes == 0 -> "بدون حتی یه اشتباه! عالی بود"
                won -> "با ${g.mistakes.fa()} اشتباه حلش کردی"
                else -> "اشکالی نداره، یه بار دیگه امتحان کن"
            },
            fontSize = 17.sp, color = C.muted
        )
        Spacer(Modifier.height(22.dp))

        Box(Modifier.fillMaxWidth().border(1.5.dp, C.line, RoundedCornerShape(28.dp)).padding(24.dp)) {
            Box(
                Modifier.align(Alignment.TopStart).size(32.dp).clip(CircleShape)
                    .border(2.dp, C.muted, CircleShape).clickable { info = true },
                contentAlignment = Alignment.Center
            ) { Text("i", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = C.muted) }
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(g.score.fa(), fontSize = 88.sp, fontWeight = FontWeight.Black, color = if (won) C.score else C.muted)
                Text("امتیاز", fontSize = 20.sp, color = C.muted)
                Spacer(Modifier.height(18.dp))
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color(0xFFF7F4EF)).padding(vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    StatChip("اشتباه", g.mistakes.fa())
                    if (!practice) StatChip("برد پشت‌هم", model.streak.fa())
                    if (!practice) StatChip("بهترین امتیاز", model.best(levelNo).fa())
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        g.solved.forEach { gi ->
            val gr = g.level.groups[gi]
            Box(Modifier.fillMaxWidth().height(1.dp).background(C.line))
            Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(24.dp).clip(RoundedCornerShape(6.dp)).background(C.rank[gr.rank]))
                Spacer(Modifier.width(12.dp))
                Text(
                    buildAnnotatedString {
                        withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(gr.title) }
                        append(" (" + gr.words.joinToString("، ") + ")")
                    },
                    fontSize = 17.sp
                )
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(C.line))
        Spacer(Modifier.height(24.dp))

        if (practice) {
            AccentButton("بریم سراغ بازی اصلی", onExitPractice)
            Spacer(Modifier.height(12.dp))
            Pill("یه دست دیگه", enabled = true, onClick = onReplay)
        } else {
            if (levelNo < Levels.COUNT) AccentButton("مرحله بعدی", { onOpen(levelNo + 1) })
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Pill("دوباره", enabled = true, onClick = onReplay)
                Pill("مرحله‌ها", enabled = true, onClick = onLevels)
                Pill("اشتراک", enabled = true) {
                    val i = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, shareText(g, levelNo))
                    }
                    ctx.startActivity(Intent.createChooser(i, null))
                }
            }
        }
        Spacer(Modifier.height(40.dp))
    }

    if (info) {
        AlertDialog(
            onDismissRequest = { info = false },
            confirmButton = { TextButton(onClick = { info = false }) { Text("باشه") } },
            title = { Text("امتیاز چطور حساب می‌شه؟", fontWeight = FontWeight.Bold) },
            text = { Text("هر مرحله ۱۰۰ امتیاز داره و به ازای هر اشتباه ۱۰ امتیاز کم می‌شه. اگه چهار بار اشتباه کنی، رشته پاره می‌شه و امتیازی نمی‌گیری.") },
            containerColor = C.bg
        )
    }
}

@Composable
fun StatChip(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 24.sp, fontWeight = FontWeight.Black)
        Text(label, fontSize = 13.sp, color = C.muted)
    }
}

/* ───────────────────────── Levels screen ───────────────────────── */

@Composable
fun LevelsScreen(model: AppModel, onPick: (Int) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
            Text("مرحله‌ها", fontSize = 26.sp, fontWeight = FontWeight.Black)
            Text(
                "${model.completed().fa()} از ${Levels.COUNT.fa()} مرحله انجام شده",
                fontSize = 15.sp, color = C.muted
            )
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(5),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(Levels.COUNT) { i ->
                val n = i + 1
                val r = model.results[n]
                val open = model.unlocked(n)
                val base = when {
                    r == 0 -> C.pink.copy(alpha = 0.40f)
                    r >= 100 -> C.green.copy(alpha = 0.55f)
                    r > 0 -> C.blue.copy(alpha = 0.40f)
                    open -> C.tile
                    else -> C.tile.copy(alpha = 0.45f)
                }
                val shape = RoundedCornerShape(14.dp)
                Box(
                    Modifier.aspectRatio(1f).clip(shape).background(base)
                        .border(if (n == model.current) 2.dp else 0.dp, C.ink, shape)
                        .clickable(enabled = open) { onPick(n) },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(n.fa(), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = if (open) C.ink else C.dim)
                        if (r > 0) Text(r.fa(), fontSize = 11.sp, color = C.muted)
                    }
                }
            }
        }
    }
}

/* ───────────────────────── Dialogs ───────────────────────── */

@Composable
fun Sheet(onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            Modifier.padding(16.dp).fillMaxWidth(),
            shape = RoundedCornerShape(28.dp), color = C.bg, contentColor = C.ink
        ) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(24.dp), content = content)
        }
    }
}

@Composable
fun MenuDialog(onClose: () -> Unit, onPick: (String) -> Unit) {
    Sheet(onClose) {
        val items = listOf(
            "levels" to "انتخاب مرحله", "stats" to "آمار من", "help" to "راهنمای بازی",
            "practice" to "بازی تمرینی", "reset" to "پاک کردن پیشرفت"
        )
        items.forEachIndexed { i, (id, label) ->
            if (i > 0) Box(Modifier.fillMaxWidth().height(1.dp).background(C.line))
            Text(
                label, fontSize = 19.sp, fontWeight = FontWeight.Bold,
                color = if (id == "reset") C.accent else C.ink,
                modifier = Modifier.fillMaxWidth().clickable { onPick(id) }.padding(vertical = 16.dp)
            )
        }
    }
}

@Composable
fun StatsDialog(model: AppModel, onClose: () -> Unit) {
    Sheet(onClose) {
        Text("آمار من", fontSize = 28.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(18.dp))
        val rate = if (model.played == 0) 0 else model.wins * 100 / model.played
        listOf(
            "مرحله‌های انجام‌شده" to "${model.completed().fa()} از ${Levels.COUNT.fa()}",
            "بازی‌ها" to model.played.fa(),
            "بُردها" to model.wins.fa(),
            "درصد برد" to "${rate.fa()}٪",
            "برد پشت‌سرهم" to model.streak.fa(),
            "بیشترین برد پشت‌سرهم" to model.bestStreak.fa(),
            "بدون هیچ اشتباه" to model.perfect.fa()
        ).forEach { (k, v) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 11.dp)) {
                Text(k, fontSize = 17.sp, modifier = Modifier.weight(1f))
                Text(v, fontSize = 18.sp, fontWeight = FontWeight.Black)
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(C.line))
        }
        Spacer(Modifier.height(18.dp))
        Pill("بستن", enabled = true, onClick = onClose)
    }
}

@Composable
fun HelpDialog(onClose: () -> Unit, onPractice: () -> Unit) {
    Sheet(onClose) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("چطور بازی کنم؟", fontSize = 30.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
            Text("✕", fontSize = 26.sp, modifier = Modifier.clickable { onClose() }.padding(8.dp))
        }
        Spacer(Modifier.height(10.dp))
        Text("گروه‌های چهارتایی پیدا کن که یه وجه مشترک دارن.", fontSize = 18.sp, lineHeight = 30.sp)
        Spacer(Modifier.height(20.dp))
        HelpStep("۱", "۴ کاشی انتخاب کن و «ثبت» رو بزن.")
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("کتاب", "آشپز", "رود", "مهمان").forEach { w ->
                Box(
                    Modifier.weight(1f).height(54.dp).clip(RoundedCornerShape(10.dp)).background(C.ink),
                    contentAlignment = Alignment.Center
                ) { Text(w, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
            }
        }
        Spacer(Modifier.height(18.dp))
        HelpStep("۲", "هر بازی فقط یه جواب داره. حواست به کلمه‌هایی باشه که انگار توی دو گروه جا می‌شن!")
        Spacer(Modifier.height(10.dp))
        Column(
            Modifier.fillMaxWidth().height(64.dp).clip(RoundedCornerShape(10.dp)).background(C.green),
            verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("… + خانه یک کلمه معنادار است", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text("کتاب، آشپز، رود، مهمان", fontSize = 14.sp)
        }
        Spacer(Modifier.height(18.dp))
        HelpStep("۳", "تا ۴ اشتباه مجازی. رنگ هر گروه سختیش رو نشون می‌ده:")
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            listOf("آسون" to C.green, "متوسط" to C.blue, "سخت" to C.yellow, "خیلی سخت" to C.pink).forEach { (n, c) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(20.dp).clip(RoundedCornerShape(5.dp)).background(c))
                    Spacer(Modifier.width(5.dp))
                    Text(n, fontSize = 13.sp, color = C.muted)
                }
            }
        }
        Spacer(Modifier.height(26.dp))
        AccentButton("فهمیدم", onClose)
        Spacer(Modifier.height(12.dp))
        Pill("یه دست تمرینی بزن", enabled = true, onClick = onPractice)
    }
}

@Composable
fun HelpStep(n: String, text: String) {
    Row(verticalAlignment = Alignment.Top) {
        Box(Modifier.size(38.dp).clip(CircleShape).background(C.ink), contentAlignment = Alignment.Center) {
            Text(n, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(12.dp))
        Text(text, fontSize = 17.sp, lineHeight = 28.sp, modifier = Modifier.weight(1f))
    }
}
