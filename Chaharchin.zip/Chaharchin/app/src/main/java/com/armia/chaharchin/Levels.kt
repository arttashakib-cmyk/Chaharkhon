package com.armia.chaharchin

import android.content.Context
import kotlin.random.Random

class Cat(val tier: Int, val title: String, val words: List<String>) {
    val set: Set<String> = words.toHashSet()
}

class Group(val title: String, val words: List<String>, val rank: Int)

class Level(
    val number: Int,
    val groups: List<Group>,
    val start: List<String>,
    val catIdx: List<Int>
) {
    val groupOf: Map<String, Int> = buildMap {
        groups.forEachIndexed { i, g -> g.words.forEach { put(it, i) } }
    }
}

/**
 * Levels are generated deterministically from assets/categories.txt.
 * Line format:  tier|title|word،word،word،...
 *   tier 1 = easy ... tier 4 = very hard
 *   title shortcuts:  P:xxx  ->  "xxx + … یک کلمه معنادار است"
 *                     S:xxx  ->  "… + xxx یک کلمه معنادار است"
 * Add lines to the file and levels will use them automatically.
 */
object Levels {
    const val COUNT = 300

    private var cats: List<Cat> = emptyList()
    val categoryCount: Int get() = cats.size

    fun init(ctx: Context) {
        if (cats.isNotEmpty()) return
        val out = ArrayList<Cat>()
        ctx.assets.open("categories.txt").bufferedReader(Charsets.UTF_8).useLines { lines ->
            lines.forEach { raw ->
                val line = raw.trim()
                if (line.isEmpty() || line.startsWith("#")) return@forEach
                val p = line.split("|")
                if (p.size < 3) return@forEach
                val tier = p[0].trim().toIntOrNull() ?: return@forEach
                val t = p[1].trim()
                val title = when {
                    t.startsWith("P:") -> t.drop(2) + " + … یک کلمه معنادار است"
                    t.startsWith("S:") -> "… + " + t.drop(2) + " یک کلمه معنادار است"
                    else -> t
                }
                val words = p[2].split("،").map { it.trim() }.filter { it.isNotEmpty() }.distinct()
                if (words.size >= 4) out.add(Cat(tier, title, words))
            }
        }
        cats = out
    }

    private fun plan(n: Int): List<Int> = when {
        n <= 10 -> listOf(1, 1, 1, 2)
        n <= 30 -> listOf(1, 1, 2, 2)
        n <= 60 -> listOf(1, 2, 2, 3)
        n <= 100 -> listOf(1, 2, 3, 3)
        n <= 150 -> if (n % 3 == 0) listOf(1, 2, 3, 4) else listOf(1, 2, 3, 3)
        n <= 220 -> if (n % 2 == 0) listOf(2, 3, 3, 4) else listOf(1, 2, 3, 4)
        else -> if (n % 5 == 0) listOf(3, 3, 4, 4) else listOf(2, 3, 3, 4)
    }

    // two groups are "swap-ambiguous" if a word of each fits the other's category
    private fun clash(wa: List<String>, ca: Cat, wb: List<String>, cb: Cat): Boolean =
        wa.any { it in cb.set } && wb.any { it in ca.set }

    private fun build(n: Int, attempt: Int, usage: IntArray?, strict: Boolean): Level? {
        val rng = Random(n * 7919L + attempt * 104729L + 17L)
        val used = HashSet<String>()
        val chosen = ArrayList<Int>()
        val groups = ArrayList<Group>()
        val plan = plan(n)
        for ((rank, tier) in plan.withIndex()) {
            val cand = cats.indices
                .filter { cats[it].tier == tier && it !in chosen }
                .map { it to (rng.nextInt(1000) + (usage?.get(it) ?: 0) * 1000) }
                .sortedBy { it.second }
            var picked = false
            for ((idx, _) in cand) {
                val pool = cats[idx].words.filter { it !in used }
                if (pool.size < 4) continue
                val w = pool.shuffled(rng).take(4)
                if (strict) {
                    var bad = false
                    for (j in chosen.indices) {
                        if (clash(w, cats[idx], groups[j].words, cats[chosen[j]])) { bad = true; break }
                    }
                    if (bad) continue
                }
                used.addAll(w)
                chosen.add(idx)
                groups.add(Group(cats[idx].title, w, rank))
                picked = true
                break
            }
            if (!picked) return null
        }
        val start = groups.flatMap { it.words }.shuffled(rng)
        return Level(n, groups, start, chosen)
    }

    val all: List<Level> by lazy {
        val usage = IntArray(cats.size)
        (1..COUNT).map { n ->
            var lv: Level? = null
            var a = 0
            while (lv == null && a < 300) { lv = build(n, a, usage, true); a++ }
            a = 0
            while (lv == null && a < 300) { lv = build(n, a, usage, false); a++ }
            val r = lv!!
            r.catIdx.forEach { usage[it]++ }
            r
        }
    }

    fun practice(): Level =
        (0..200).firstNotNullOf { build(0, it, null, true) }
}
